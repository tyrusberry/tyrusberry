function [X,Yr] = PCA(Y,p)
%%% Algorithm 1.1 Principal Component Analysis (PCA)
%%% Inputs: Y  - n-by-N matrix with columns y_i in R^n for i=1,...,N
%           k  - Number of PCA modes to project onto
%%% Output: X  - k-by-N matrix, projection onto first k PCA modes
%           Yr - n-by-N matrix, reconstruction of Y from k PCA components








